# Signal — Frontend portfolio starter

A hero-first Next.js App Router portfolio with TypeScript and Tailwind CSS 3. The initial scope includes the video hero, a small supporting approach section, and reusable primitives. Project grids, experience timelines and contact forms can be added as independent feature modules later.

## Run

Requires Node.js 20.9+.

```sh
npm install
npm run dev
npm run typecheck
npm run build
npm start
```

`npm run build` exports the site to `out/`. `npm start` serves that export. Google fonts are downloaded during the build by `next/font/google`; build machines need network access to Google Fonts.

## Edit your content

Edit `src/config/portfolio.ts`: replace the sample brand, availability, `hello@example.com`, text, skills, and Pexels CDN URL before public launch. Email actions open the visitor's mail client; no messages are submitted to a backend. The stock URL is a configurable sample, not a guaranteed production media service. Host a compressed licensed MP4/WebM locally for predictable production availability. Add alternatives to `media.sources` in preferred order.

## Architecture

```text
src/
  app/                     Route composition, fonts, metadata, global styles
  components/
    common/                Native button/link, video and surface primitives
    features/              Portfolio boundary, header, approach and hero modules
  hooks/                   Media state and reduced-motion preference
  types/                   Lean content and provider contracts
  config/                  Replaceable local content adapter
```

- **SRP:** media behavior lives in `useBackgroundVideo`; media, copy, toolkit and composition each have their own component. The async server boundary loads content.
- **OCP:** Hero accepts children; primitives accept children; repeated content is data driven. Extend theme tokens without editing features.
- **LSP:** Button, ButtonLink and VideoPlayer forward native element attributes and refs. Anchors remain anchors. GlassCard preserves native div attributes.
- **ISP:** leaf components receive small contracts or primitive fields instead of the whole portfolio.
- **DIP:** PortfolioPage receives a PortfolioProvider interface. Only app/page.tsx chooses the local adapter. Swap for a CMS adapter implementing getPortfolio without editing presentation components. With static export, providers run at build time; dynamic content requires rebuilding or changing the hosting model.

## Accessibility and media

Keyboard focus, a skip link, semantic headings, responsive type, readable overlay, and explicit motion controls are included. Reduced-motion users do not load the video. Autoplay is muted and inline; blocked autoplay retains a play control when media is ready. Failed media leaves the gradient/grid fallback intact. Motion CSS also respects reduced-motion preferences. Decorative video is hidden from assistive technology.

## Theme

RGB color values live in `src/app/globals.css`, are exposed through `tailwind.config.js`, and support Tailwind opacity modifiers. `next/font/google` exposes Space Grotesk and JetBrains Mono as CSS variables. Utilities include `glass-panel`, `radial-grid` and `shadow-neon-cyan`.

## References

- https://nextjs.org/docs/app/api-reference/components/font
- https://nextjs.org/docs/app/guides/static-exports
- https://www.pexels.com/video/3129671/
