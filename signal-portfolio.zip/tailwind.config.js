/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    // OCP: extend the design system through tokens without editing components.
    extend: {
      fontFamily: {
        display: ["var(--font-space-grotesk)", "sans-serif"],
        mono: ["var(--font-jetbrains-mono)", "monospace"],
      },
      colors: {
        cyber: {
          dark: "rgb(var(--cyber-dark) / <alpha-value>)",
          surface: "rgb(var(--cyber-surface) / <alpha-value>)",
          text: "rgb(var(--cyber-text) / <alpha-value>)",
          muted: "rgb(var(--cyber-muted) / <alpha-value>)",
          cyan: "rgb(var(--cyber-cyan) / <alpha-value>)",
          purple: "rgb(var(--cyber-purple) / <alpha-value>)",
        },
      },
      boxShadow: { "neon-cyan": "0 0 32px rgb(var(--cyber-cyan) / 0.16)" },
      keyframes: { reveal: { from: { opacity: "0", transform: "translateY(18px)" }, to: { opacity: "1", transform: "translateY(0)" } } },
      animation: { reveal: "reveal 800ms ease-out both" },
    },
  },
  plugins: [],
};
