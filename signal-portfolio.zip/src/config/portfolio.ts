import type { PortfolioContent, PortfolioProvider } from "@/types/portfolio";

// SRP: editable sample content lives outside rendering and interaction code.
const content: PortfolioContent = {
  brand: "signal",
  availability: "Available for select projects",
  contactEmail: "hello@example.com", // Replace with your own email before sharing publicly.
  hero: {
    eyebrow: "INDEPENDENT FRONTEND DEVELOPER",
    heading: "Human ideas.",
    highlight: "Digital futures.",
    description: "I turn ambitious ideas into fast, thoughtful web experiences. Built with precision. Designed to feel effortless.",
  },
  media: {
    // Replaceable Pexels CDN sample. The CSS fallback remains if the CDN is unavailable.
    sources: [{ src: "https://videos.pexels.com/video-files/3129671/3129671-hd_1920_1080_30fps.mp4", type: "video/mp4" }],
    sourceUrl: "https://www.pexels.com/video/3129671/",
  },
  technologies: ["Next.js", "React", "TypeScript", "Tailwind CSS"],
  capabilities: [
    { label: "Interfaces that feel right", description: "Thoughtful interaction. Every screen, every size." },
    { label: "Built for what’s next", description: "Clean architecture that grows with your product." },
    { label: "Performance by design", description: "Fast, accessible experiences from the first render." },
  ],
};

// DIP: this is the replaceable infrastructure adapter, not a UI dependency.
export const localPortfolioProvider: PortfolioProvider = {
  async getPortfolio() { return content; },
};
