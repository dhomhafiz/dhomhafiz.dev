// ISP: small domain contracts prevent primitives from depending on an entire page.
export interface HeroCopy {
  eyebrow: string;
  heading: string;
  highlight: string;
  description: string;
}
export interface VideoSource {
  src: string;
  type: string;
}
export interface HeroMedia {
  sources: readonly VideoSource[];
  sourceUrl: string;
}
export interface Capability { label: string; description: string }
export interface PortfolioContent {
  brand: string;
  availability: string;
  contactEmail: string;
  hero: HeroCopy;
  media: HeroMedia;
  technologies: readonly string[];
  capabilities: readonly Capability[];
}
// DIP: any CMS, API, or local adapter may satisfy this boundary.
export interface PortfolioProvider { getPortfolio(): Promise<PortfolioContent> }
