"use client";

import { useCallback, useEffect, useRef, useState } from "react";

// SRP: playback, reduced-motion preference, and media failure are isolated from UI.
export function useBackgroundVideo() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState(false);
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => {
      setAllowed(!preference.matches);
      if (preference.matches) videoRef.current?.pause();
    };
    sync();
    preference.addEventListener("change", sync);
    return () => preference.removeEventListener("change", sync);
  }, []);

  const toggle = useCallback(async () => {
    const video = videoRef.current;
    if (!video || failed) return;
    if (!video.paused) video.pause();
    else {
      try { await video.play(); } catch { setPlaying(false); }
    }
  }, [failed]);

  return { videoRef, ready, playing, failed, allowed, toggle,
    onReady: () => setReady(true), onPlay: () => setPlaying(true),
    onPause: () => setPlaying(false), onError: () => { setFailed(true); setPlaying(false); },
  };
}
