import type { ReactNode } from "react";
import { HeroBackdrop } from "./HeroBackdrop";
import { HeroCopy } from "./HeroCopy";
import type { HeroCopy as HeroCopyModel, VideoSource } from "@/types/portfolio";

interface HeroProps { copy: HeroCopyModel; sources: readonly VideoSource[]; contactEmail: string; children?: ReactNode }

// SRP: composition only. OCP: its lower slot supports new content without modifying Hero.
export function Hero({ copy, sources, contactEmail, children }: HeroProps) {
  return <section aria-label="Introduction" className="relative isolate overflow-hidden border-b border-white/10">
    <HeroBackdrop sources={sources} />
    <div className="relative mx-auto flex min-h-[min(850px,calc(100svh-88px))] max-w-[1440px] flex-col justify-center px-6 pb-28 pt-20 md:px-12 lg:px-20 lg:pt-28">
      <HeroCopy {...copy} contactEmail={contactEmail} />
      <div className="relative z-10 mt-16 lg:mt-24">{children}</div>
    </div>
  </section>;
}
