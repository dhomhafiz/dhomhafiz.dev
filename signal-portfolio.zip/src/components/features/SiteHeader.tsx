import { ButtonLink } from "@/components/common/Button";

// ISP: the header receives primitives instead of a whole portfolio object.
export function SiteHeader({ brand, availability, contactEmail }: { brand: string; availability: string; contactEmail: string }) {
  return <header className="relative z-30 border-b border-white/10 bg-cyber-dark">
    <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-6 py-5 md:px-12 lg:px-20">
      <a href="#main" aria-label={`${brand} home`} className="flex items-center gap-3 font-display text-2xl font-semibold tracking-tight">
        <span aria-hidden="true" className="text-cyber-cyan">//</span>{brand}<span className="text-cyber-cyan">.</span>
      </a>
      <p className="hidden items-center gap-2 text-xs text-cyber-muted md:flex"><span className="h-1.5 w-1.5 rounded-full bg-cyber-cyan" aria-hidden="true" />{availability}</p>
      <ButtonLink href={`mailto:${contactEmail}`} variant="secondary" className="!min-h-11 !px-4 !py-2">Let’s talk <span aria-hidden="true">↗</span></ButtonLink>
    </div>
  </header>;
}
