import type { PortfolioProvider } from "@/types/portfolio";
import { SiteHeader } from "./SiteHeader";
import { Hero } from "./hero/Hero";
import { TechnologyStrip } from "./hero/TechnologyStrip";
import { Approach } from "./Approach";

// DIP: this server-side boundary accepts any provider implementing the interface.
// SRP: fetching occurs here, while the feature components only render their inputs.
export async function PortfolioPage({ provider }: { provider: PortfolioProvider }) {
  const content = await provider.getPortfolio();
  return <>
    <SiteHeader brand={content.brand} availability={content.availability} contactEmail={content.contactEmail} />
    <main id="main">
      <Hero copy={content.hero} sources={content.media.sources} contactEmail={content.contactEmail}>
        <TechnologyStrip items={content.technologies} />
      </Hero>
      <Approach items={content.capabilities} />
    </main>
    <footer className="mx-auto flex max-w-[1440px] flex-wrap justify-between gap-4 border-t border-white/10 px-6 py-7 text-xs text-cyber-muted md:px-12 lg:px-20">
      <span>{content.brand}. / Independent by design.</span>
      <a href={content.media.sourceUrl} target="_blank" rel="noreferrer" className="underline decoration-white/20 underline-offset-4 hover:text-cyber-cyan">Background footage / Pexels ↗</a>
    </footer>
  </>;
}
